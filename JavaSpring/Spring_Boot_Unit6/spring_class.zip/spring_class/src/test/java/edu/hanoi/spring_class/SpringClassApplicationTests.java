package edu.hanoi.spring_class;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
