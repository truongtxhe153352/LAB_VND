package edu.hanoi.jazz.springjazztry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJazzTryApplicationTests {

	@Test
	void contextLoads() {
	}

}
