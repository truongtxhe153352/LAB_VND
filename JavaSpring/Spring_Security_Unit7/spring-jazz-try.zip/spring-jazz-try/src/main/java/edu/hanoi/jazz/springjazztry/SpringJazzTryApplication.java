package edu.hanoi.jazz.springjazztry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJazzTryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJazzTryApplication.class, args);
	}

}
