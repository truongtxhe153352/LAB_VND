package edu.hanoi.jazz.springjazz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJazzApplicationTests {

	@Test
	void contextLoads() {
	}

}
