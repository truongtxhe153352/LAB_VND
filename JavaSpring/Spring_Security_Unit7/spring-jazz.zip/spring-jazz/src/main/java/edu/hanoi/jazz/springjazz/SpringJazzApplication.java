package edu.hanoi.jazz.springjazz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJazzApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJazzApplication.class, args);
	}

}
